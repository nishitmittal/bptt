import os
import tensorflow as tf
import numpy as np
import argparse, random
import pandas as pd
from model import GRU4Rec
from utils import load_train, load_valid

unfold_max = 20
error_during_training = False


PATH = 'data'
TRAINFILE = 'data/rsc15_train_full.txt'
TESTFILE = 'data/rsc15_test.txt'
VALIDFILE = 'data/rsc15_train_valid.txt'

def get_item():
    train = pd.read_csv(TRAINFILE, sep='\t', dtype={0:str, 1:str, 2:np.float32})
    valid = pd.read_csv(VALIDFILE, sep='\t', dtype={0:str, 1:str, 2:np.float32})
    test =  pd.read_csv(TESTFILE, sep='\t', dtype={0:str, 1:str, 2:np.float32})
    data1 = pd.concat([train, valid, test])
    return data1.ItemId.unique()



if os.path.exists('item2id.map'):
        item2idmap = {}
        for line in open('item2id.map'):
            k, v = line.strip().split('\t')
            item2idmap[k] = int(v)
        else:
            items = get_item()
            item2idmap = dict(zip(items, range(1, 1+items.size))) 
            with open('item2id.map', 'w') as fout:
                for k, v in item2idmap.items():
                    fout.write(str(k) + '\t' + str(v) + '\n')
    
max_len =20
n_items = len(item2idmap)
train = pd.read_csv(TRAINFILE, sep='\t', dtype={0:str, 1:str, 2:np.float64})       
train['ItemId'] = train['ItemId'].map(item2idmap)
train = train.sort_values(by=['Timestamp']).groupby('SessionId')['ItemId'].apply(list).to_dict()
train_x = []
train_y = []
for k, v in train.items():
        x = v[:-1]
        y = v[1:]
        if len(x) < 2:
            continue
        padded_len = max_len - len(x)
        if padded_len > 0:
            x.extend([0] * padded_len)
            y.extend([0] * padded_len)
        train_x.append(x[:max_len])
        train_y.append(y[:max_len]) 

valid = pd.read_csv(VALIDFILE, sep='\t', dtype={0:str, 1:str, 2:np.float64})       
valid['ItemId'] = valid['ItemId'].map(item2idmap)
valid = valid.sort_values(by=['Timestamp']).groupby('SessionId')['ItemId'].apply(list).to_dict()
valid_x = []
valid_y = []
for k, v in valid.items():
        x = v[:-1]
        y = v[1:]
        if len(x) < 2:
            continue
        padded_len = max_len - len(x)
        if padded_len > 0:
            x.extend([0] * padded_len)
            y.extend([0] * padded_len)
        valid_x.append(x[:max_len])
        valid_y.append(y[:max_len]) 