# -*- coding: utf-8 -*-
"""
Created on Feb 27 2017
Author: Weiping Song
"""
import sys
import numpy as np
import argparse
import tensorflow as tf

from model import GRU4Rec
#from utils import load_test

unfold_max = 20
cut_off = 20

from untitledww import train_x,train_y, n_items, valid_x,valid_y

class Args():
    is_training = False
    layers = 1
    rnn_size = 100
    n_epochs = 1
    batch_size = 50
    keep_prob = 1
    learning_rate = 0.002
    decay = 0.98
    decay_steps = 1e3*5
    sigma = 0.0005
    init_as_normal = False
    grad_cap = 0
    test_model = 9
    checkpoint_dir = 'save/{}'.format('lstm')
    loss = 'cross-entropy'
    final_act = 'softmax'
    hidden_act = 'tanh'
    n_items = -1

def parseArgs():
    args = Args()
    parser = argparse.ArgumentParser(description='GRU4Rec args')
    parser.add_argument('--layer', default=1, type=int)
    parser.add_argument('--size', default=100, type=int)
    parser.add_argument('--batch', default=256, type=int)
    parser.add_argument('--epoch', default=5, type=int)
    parser.add_argument('--lr', default=0.001, type=float)
    parser.add_argument('--dr', default=0.98, type=float)
    parser.add_argument('--ds', default=400, type=int)
    parser.add_argument('--keep', default='1.0', type=float)
    command_line = parser.parse_args()
    
    args.layers = command_line.layer
    args.batch_size = command_line.batch
    args.n_epochs = command_line.epoch
    args.learning_rate = command_line.lr
    args.rnn_size = command_line.size
    args.keep_prob = command_line.keep
    args.decay = command_line.dr
    args.decay_steps = command_line.ds
    args.checkpoint_dir += ('_p' + str(command_line.keep))
    args.checkpoint_dir += ('_rnn' + str(command_line.size))
    args.checkpoint_dir += ('_batch'+str(command_line.batch))
    args.checkpoint_dir += ('_lr'+str(command_line.lr))
    args.checkpoint_dir += ('_dr'+str(command_line.dr))
    args.checkpoint_dir += ('_ds'+str(command_line.ds))
    args.checkpoint_dir += ('_unfold'+str(unfold_max))
    return args

def evaluate(args):
    '''
    Returns
    --------
    out : tuple
        (Recall@N, MRR@N)
    '''
    args.n_items = n_items
    evaluation_point_count = 0
    mrr_l, recall_l, ndcg20_l, ndcg_l = 0.0, 0.0, 0.0, 0.0
    np.random.seed(42)
    
    gpu_config = tf.ConfigProto()
    gpu_config.gpu_options.allow_growth = True
    model = GRU4Rec(args)
    with tf.Session(config=gpu_config) as sess:
        #tf.global_variables_initializer().run()
        saver = tf.train.Saver(tf.global_variables())
        ckpt = tf.train.get_checkpoint_state(args.checkpoint_dir)
        if ckpt and ckpt.model_checkpoint_path:
            saver.restore(sess, ckpt.model_checkpoint_path)
            print('Restore model from {} successfully!'.format(args.checkpoint_dir))
        else:
            print('Restore model from {} failed!'.format(args.checkpoint_dir))
            return
        batch_idx = 0
        while batch_idx < len(valid_x):
            batch_x = valid_x[batch_idx: batch_idx + args.batch_size]
            batch_y = valid_y[batch_idx: batch_idx + args.batch_size]
            feed_dict = {model.X: batch_x, model.Y: batch_y}
            hit, ndcg, n_target = sess.run([model.hit_at_k, model.ndcg_at_k, model.num_target], feed_dict=feed_dict)
            recall_l += hit
            ndcg_l += ndcg
            evaluation_point_count += n_target
            batch_idx += args.batch_size

    return recall_l / evaluation_point_count, ndcg_l / evaluation_point_count

if __name__ == '__main__':
    args = parseArgs()
    res = evaluate(args)
    print('lr: {}\tbatch_size: {}\tdecay_steps:{}\tdecay_rate:{}\tkeep_prob:{}\tdim: {}\tlayer: {}'.format(args.learning_rate, args.batch_size, args.decay_steps, args.decay, args.keep_prob, args.rnn_size, args.layers))
    print('Recall@20: {}\tNDCG: {}'.format(res[0], res[1]))
    sys.stdout.flush()
